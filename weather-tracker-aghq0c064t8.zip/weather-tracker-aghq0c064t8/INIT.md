To get started choose Run > Install from the menu bar above!
