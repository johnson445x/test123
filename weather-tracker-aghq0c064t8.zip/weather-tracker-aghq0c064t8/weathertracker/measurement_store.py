from .measurement import Measurement
from werkzeug.exceptions import abort


def add_measurement(measurement):
    # TODO:
    Measurement.set_metric
    abort(501)


def get_measurement(date):
    # TODO:
    abort(501)


def query_measurements(start_date, end_date):
    # TODO:
    abort(501)
